var lvl1_nerf=`
 c
lhHhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhH r r
 r          rC                        r r
 r          r                         r r
 r          rrrrr rrrrrrrrrrrrrrrrrrrrr r
lr          r                         r r
 r          r                         r r
 r          r    r rr  rrrrrrrrr  rrrrr r
 r          r    r r               cr r r
lr          rrrr r r                r r r
 r               r r rrrrrrrrrrrrrr r r r
 r               r r                  r r
 rrrrrrrrrrrr    r r                  r r
lrCc        r  rrr rrrrrrrrrrrrrrrrrr r r
 r             r                      r r
 r             rC                    cr r
 rrrrrrrrrrrrrrr                      r r
lrcccccccccccccr                      r r
  cccccccccccccr                      r r
  cccccccccccccr                      r r
 r rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr r
 r                                      r
 r                                      r
 r                                      r
 rr            l           l     l      r
 rrl rl rl rl rl rl   rrl rl rl rl rll rr

 llllllllllllllllllllllllllllllllllllllll

 CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
`
var lvl1=
`                                zzzzzzzz

 v                                      v
 r    e    e     e     e     e          vZ
 rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr  r
 r                                    r r
 r                                    r  r
 r                                    r   r
 r                                    r    r
 r   rrrrrrrrrrrr rrrrrrrrrrrrrrrrrrrrr     r
 r          r     v                   r r    r
 r          rvvvv                             r
 r          r    rvrrvrrrrrrrrrrrvrrrrrvrr     r
 r          r    r r               cr r r r     r
 r          rrrr r r                r r r  r     r
 r               r r rrrrrrrrrrrrrrrr r r   l    lr
 rrrrrrrr        r r                  r r    r   llr
 r      rrrr     r r                  r r         llr
 rCc        rrrrr   rrrrrrrrrrrrrrrrr r r        l  lr
 r                                    r r       r
 r      z    e v z                    r r      l
 rrrrrrrrrrrrrrr z     z z z z z z  r r r     r
 rcccccccccccccr z                    r r    l
  cccccccccccccr z    z z z z z z z   r r   r
  C   C   C   Cr  z                  lr r  r
 r rrrrrrrrrrrrrllrrrrrrrrrrrrrrrrrrrrr r
 r                                      r
 r                                       r
 rzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz    r
 rr            l           l     l                         l
 rrl rl rl rl rl rl   rrl rl rl rl rll rrrrrrrrrrrrlllllllll
 l
 lllllIIIlllIIIllllIIIlllllIIIlllIIIlIIIll

 CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCn
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
`

var lvl2 = `
l
l
l
f
f
f
f
l
l
l     s
rrrrrrrrr          r       r       r       r       r       r
r
r
r                                                                  r
r
r
r                                                                        r
r
r      ie
lfllllllllllllllllllllllllllllllllGffGlllllllllllllllllllllllllllll llllllllllllllr            l
                                                                    v                          l
                                                                    v                          l
                     c    c                                         v                  c       l
           cll      c  c  l  c                                      v                  c       l
    c  c l    l        l     l  c       zlz lz  z  zl z  zllllcz  zl                  c        l
    l   l      c  lz   l     l  c        l  lc   c     c  c c   c   c l  l  l  l  l  l c       l
 n               l  z   ccc     llllzclzc  c     lz    lz       lz lz  c  c  c  c  c r cǝ      l
 r lrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
`
var DESTRUCTION=
`


                                   rrrr   rrrrrrrrrrrrrrrrrrrrrrrrr l
                                   r                   r            l
                                   r                   r            l
                                   r                   r            l
             C                     r                   r            l
             C                     r                   r            l
        rrrFFFFF                   ree                 r            l
                                   r rrrrrrrrfffrrrrrrrr
    rrrrr                          r
                                   r
                                   rrrrrrrrrrrrrrrrrrrrrrrr    frrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr         rrrrffrrr c
rrrr
      rrrrr
                                                  rrrrrrrrr
               rrr
                  rrrrrrr
l
l                         rrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
l                                                        rrrrr
l          l
l          l
l          l                                                     r
r   e        ǝ ǝ ǝ ǝ ǝ ǝ ǝ    zrzzcccc                     rrrrrrr
rrrrrrr  rrrrrrrrrrrrrrrrr z  rllllllr                    r
f                           zrllllllll                  r
f                          zr             r       rrrrrrrrr
r                         zr
r                        zr             l
r                       zrcccccccccc rrrr
r  r                   zrccccccccccccr
rrrrrrrrrrrrrrrrrrrrrrrrrr rrrrrrrrrrr       IIIIIIIIIIIIII  I
I                                                            I
I                                                        rIIII
I                                                        r             iiiiiiiiiiii
I                                                        r
I                           lllllllllllFFFFFFFFFrrrrrrrrrr
I        iiiii    rccccccc r  lrr                                                     iiiiiiiiiiiii
    CCCCCCC i    rrrrrrrrrr
     iiiii ii

    i                          c                                                                    i i
                       rrr  cccrr                                                                   i i
            ---rccc r ǝǝǝǝǝ rrr
r-r    eee    rrrrrrrrrrrrrr       r                                                                   CCCCCCC
rrrrrrrrrrrrrrrr
rcccccccccccccc                r   ee   r                                                            rrrrrrrrrrrrrrrrrr
rcccccccccccccc  l              rrrrrrrr
r CCCCCCCCCCCCCCC            r
r          e        r  r rrr
rrrrrrrrrrrrrrrrrrrr






                                                                                                                        iiiiiiiiiiiiiiiiiiiiir





                                                                                                                                             iiiiiiii


                                                         CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
                                                        rrrrrrrrFFFFrrrrrrlllllllrlllllrrrrr         CCCCCCCCCCCCCCCCCC
iiiiiiiiiiiiii                              r       r                                                rrrrrrrrrrrrrrrrrr
                 cccccccccc       r
                 rrrrrrrrrr                                                                                                                         iiiiii



                                                                                                                                                           iiiir



                                                                                                                            i                    ee         i
                                                                                                                            iiiiiiiiiiiiiiiiiiiiiiiiifiiiiiii
                                                                                                                            i                              i
                                                                                                                            i CCCCCCCCCCCCCCCCCCCCCCCCCC   iC
                                                                                                                            iiiiiiiiiiiiiiiiiiiiiiiiiiiiiIIiii








                                                                                            r                         r
                                                                                            rrrrrrffrrrrrrrrrrrrrrrrrrr
                                                                                            r                         r


                                                                                            rCCCCCCCCCCCCCCCCCCCCCCCCCr
                                                                                            rrrrrrrrrrrrrrrrrrrrrrrrr r
`

var the_plains = `
                                                                      l
                                                                      l
                                                                      l
                                                                      l
         l                                                            l
         l                                                            l
         l                                                   llllll   l
r        l                                           cl    rl      r  l
r                                                    rl    r       r  l  C
r                                                     l    r     r r  l lrrrr
r                cl                                  cl    r     r r        r
r        c       rl       l                          rl   rr     r r        r
r        l        l      l l                          l    r     r rrrrrrrr r
r        r        l     lCcCl                         l    r    rr                                                    r
r        r        l  c  lC Cl k  c   c   c   c      k l c  r     r              k        c        c        ckl   l k  lCl  n
rrrrrrrrrrrrrrrrrrrrrrrrr   rrr rrlllrlllrlllrrrr rrrrrrrrrr   crrrrrrrrrrrrrrrrrllllllllrllllllllrllllllllrrrrrrrrrrrrrrrrr
                        r       r               l l            r
                        r       r               l Cl          l
                        r       r               l  Cl         l
                        rrrrrrrrr               l   Cl      cl
                                                l           r
                                                l          l
                                                l          l
                                                l        cl
                                                l        r
                                                 l      l
                                                  lccccCl
                                                   lrrrl
`

var actual_maze = `
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrl
r                                       r
r                                       rr
r              rrr rrrrrrrrrrrrrrrr rrrrr
r                r rCC                  r
r    s           r rCC                  rr
rrrrrrrrrrrrrrrr r rrlrrlrrlrrrrrrrrrrr r
               r r                    r r
               r rCcccccccccccccccccccr r
               r rrrrrrrrrrrrrrrrrrrllr rrr
               r                      r   r
       l       r                      r   r
       lr      r                      rr  rr  cccc cccc cccc cccc cccc
       l       r                      r   rrCv e     e           e    v
       l       r C    c     c    c   cr   rrrrrrrrrrrrrrrrrrrrrrrrrrrr
       lr      rlrllllrlllllrllllrlllrr r v                          r
       l                                r v                          r
       l                                rCv   e                      r
s      l                                rrrrrrrr                     v  r
l rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr       rz     l      ele     v r
l                                                rrrrrrrrrrrrrrrrrrrrrrr
l                                         rlr                         r
rrrrrrrrrrrrrrr rrrrrrrrrrrrrrrrrrrrrrrrrrlClr c c c                 sr
r                                             rrrrrrrrrrrrrrrrrrrrrrrrr
rc c c c c c c c c c C c C c C c C c C c C c
rrrrrrrrrrrrrrrrrrrrrrr  rrrrrrrrrrrrrrrrrrrrr
r                                             r r rrrrrrrrrrrrrrrrrrrrrrrrrrrr
r                       C                     r r                            r
r rrrrrrrrrrrrrrrrrrrrrr FFFFrrrrrrrrrrrrrrrrr r r          rrrrr             r
r                                               rrr rrrrrr r           r rrr rrrrrrrrrrrrrr
r                                           c   r        r r     rrrrrrr r                r
rrrrrrrrrrrrrrrrrrrrrrrllllllrrrrrrrrrrrrrrrrrrrrc      lr   rrrr        r                r
                                            r    rrrrrr rr   r           r                r
                                            r         r rrrrrc    rrrrrrrrFFFFFFFFFFFFFFFFr
                                            rCCCCCCCCCCCr      r         r
                                            rCCCCCCCCCCCr       r        r
                                            r           l       rrrrrrrr r
                                            r           lCCCCCCCCCCCCCCr r
                                            rrrrrrrrrrrrrrrrrr         r r
                                                        r              r r
                                                        r     c c c c cr rCC
                                                        r    rrrrrrrrrrr rrrlllllllllllllll
                                                        r              rCCCl
                                                        r         cccccrCCnl
                                                        r              rrrrr
                                                        r              r
                                                        r c c c c c c cr
                                                        rrrrrrrrrrrrrrrr
`

var training = `
r           s
rrrrrrrrrrrrrllrrrr
r                    ccccccccs
r                    rrrrrrrrr       s
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrryyyyyyyyy
r           r                                             r
rn          r                                             r
rrrr   rrrrryy       rrrrrr        rrrr         rrrrrrrrrrr
r                                      r   rs             r
r                                      ruuurr             r
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
`

var tinymaze = `
r                   c
r                   r
r  r                r              c
r  r                r     e        r
r  r                rvrrrrrrrrrvrrrr                                                           yyy
r rr    c                     r                     yyyyyyyy                                  rr    n
rurr    r       e           vcr  c    lll      rrrrr                                  rrrrrrrrrr
rrrrrrrrrrrrrrrrvrrrrrrrrrrr rrrrrrrrrrr   e  r             r                      r
rrr                                   rrrrrrrr            rCCC     e            vr
        c         r       e  vcr                    rrrrrrrrrrrrrrryyyrrrrrrrrrrr
        rrrrrrrrrrrrrrrrrrrrrrr r                rrrrrnr
                              rlr              rrrrrrrrr
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
                                                                            rrrrrr
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
lllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll


`

var fortress = `
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
r                                                  r
r                                                  r
r                                                  r
r           c         c         c        c         r
r    r      l        ele        l       ele     l nr
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
`

var DEATH = `
r
r                                                                      r
rrrrrrrrrrrr                                                            r
r                                                                       rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr     r     r      r      r      rr      r
r                                                                       rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
r                                                                      eeeeeeeeeeeeeeeeeeeeeeeeeeeeee  rr
rrrrrrrrrrrrrrrrrrrrrr         rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr        rrrrrrrrrrrrrrrrrrr    r     r     r     r     r     r     r
                                                                                                                                  rr
                                                                                                                                 rr
                                                                                                                                rrllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
                                                                                 rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr



                                                       rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr
                                                                                                                                                           r
                                                                                                                                                           r
                                                                                                                                                           F
                                                                                                                                                           F
                                                                                                                                                           F
rrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrlllllllrrrlllrllllrrrrrlllllrrr








 CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
 CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCcccCCCCC
 CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
nCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
rrrrrrrrrrrrrrrrrrrrrrFFFFFrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrr

llllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllllll
`


window.phase = 1; // Unlock new levels by doing a good job.
window.levelsBeaten = 0; // Beat 2 levels to go to the next phase.
window.phases = [
    [
        {
            id: 7,
            name: "Training"
        },
        {
            id: 6,
            name: "Tiny Maze"
        },
        {
            id: 8,
            name: "Fortress"
        }
    ],
    [
        {
            id: 2,
            name: "Labyrinth"
        },
        {
            id: 5,
            name: "An Actual Maze This Time"
        }
    ],
    [
        {
            id: 1,
            name: "The Plains"
        },
        {
            id: 4,
            name: "The Basement"
        },
        {
            id: 3,
            name: "DESTRUCTION"
        }
    ]
];

function loadPhase(phasenum){
    window.phases[phasenum - 1].forEach((item, i) => {
        var el = document.createElement("option");
        el.id = item.id.toString();
        el.value = item.id.toString();
        el.innerText = item.name;
        document.getElementById("dropdown").appendChild(el);
    });
    console.log(window.phases[phasenum - 1]);
}

class Brick{
    constructor(x,y,width,height, scale,renderclass,type,text,visibleText,probability){
        this.x1=x;
        this.y1=y;
        this.x2=x+width; // For collisions
        this.y2=y+height; // For collisions
        this.probprob = probability || 1;
        this.element=document.createElement("div");
        document.getElementById("game-main").appendChild(this.element);
        this.element.className=renderclass+" "+type+" "+" brick";
        this.element.style.width=width.toString()+"px";
        this.element.style.height=height.toString()+"px";
        this.element.style.left=this.x1.toString()+"px";
        this.element.style.top=this.y1.toString()+"px";
        var elem = document.createElement("div");
        this.element.appendChild(elem);
        if (text!=undefined){
            elem.innerHTML = text;
        }
        if (visibleText!=undefined){
            var elem = document.createElement("div");
            this.element.appendChild(elem);
            elem.innerHTML = visibleText;
        }
        this.type=type;
        this.needsDomRefresh = false;
        this.scale = scale;
    }
    move(xm,ym){
        this.x1+=xm;
        this.y1+=ym;
        this.x2+=xm;
        this.y2+=ym;
        this.needsDomRefresh = true;
    }
    apply(){
        if ((this.x1 < window.innerWidth || this.x2 > 0) && (this.y1 < window.innerHeight || this.y2 > 0) && this.needsDomRefresh){ // Don't do a dom operation unless the brick is visible
            this.element.style.left=((this.x1)).toString()+"px";
            this.element.style.top=((this.y1)).toString()+"px";
            this.needsDomRefresh = false;
        }
    }
    delete(){
        this.element.parentNode.removeChild(this.element);
    }
}


class Player{
    constructor(mobile,width,height,game){
        if (mobile){
            this.joystick = new JoyStick({radius: window.innerHeight/8, x: window.innerWidth - window.innerHeight/8, y: window.innerHeight * 7/8, inner_radius: window.innerHeight/8 - 10})
        }
        this.width=width
        this.height=height
        this.game=game
        this.element=document.createElement("div");
        document.getElementById("game-main").appendChild(this.element);
        this.element.style.width=(width-1).toString()+"px";
        this.element.style.height=(height-1).toString()+"px";
        this.element.style.top=(window.innerHeight/2.5 - height/2).toString()+"px";
        this.element.style.left=(window.innerWidth/2 - width/2).toString()+"px";
        this.element.id="player";
        this.xv=0;
        this.yv=0;
        this.rightpressed=false;
        this.leftpressed=false;
        this.onground=true;
        this.score=0;
        var rect=this.element.getBoundingClientRect();
        this.x1 = rect.left;
        this.y1 = rect.top;
        this.x2 = rect.right;
        this.y2 = rect.bottom;
        // Developer mode stuff
        this.lock = "bean";
        this.checkPointNum = 0;
        this.cheat = {
            active: false,
            devView: false,
            phaser: 0, // 0 = nothing, 1 = waiting for collision to phase through, 2 = phasing through
            invincible: false,
            collidesWithLava: false,
            flying: false
        }
        this.gravity = 1;
    }
    delete(){
        this.element.parentNode.removeChild(this.element);
    }
    onkeyup(event){
        if (event.key == this.lock[this.checkPointNum]){
            this.checkPointNum ++;
            if (this.checkPointNum == this.lock.length){
                this.cheat.active = true;
                alert("All cheats unlocked!");
            }
        }
        else{
            this.checkPointNum = 0;
        }
        if (event.keyCode==37){
            this.leftpressed=false;
        }
        else if (event.keyCode==39){
            this.rightpressed=false;
        }
        if (this.cheat.active){
            switch (event.key){
                case "r":
                    this.cheat.devView = !this.cheat.devView;
                    if (this.cheat.devView){
                        document.getElementById("game-main").classList.add("revalio");
                    }
                    else{
                        document.getElementById("game-main").classList.remove("revalio");
                    }
                    break;
                case "i":
                    this.cheat.invincible = !this.cheat.invincible;
                    break;
                case "g":
                    this.gravity *= -1;
                    break;
                case "s":
                    this.cheat.phaser = 1;
                    break;
                case "j":
                    this.yv = -5 * this.gravity;
                    break;
                case "f":
                    this.cheat.flying = !this.cheat.flying;
                    break;
                case ".":
                    this.xv *= 10;
                    break;
                case "q":
                    this.gravity *= 0.;
                    break;
                case "1":
                        this.gravity = 1;
                        break;
                case "d":
                        this.xv = 0;
                        break;
                case "2":
                                this.xv = 1;
                                break;
                case "a":
                      this.game.arbitraryRestructure();
                    break;
            }16
        }
        if (event.key === "p"){
            alert("Paused. Click out of this alert box when you are ready to begin again.");
        }
    }
    onkeydown(event){
        console.log(event.key);
        if (event.keyCode==38 && (this.onground || this.cheat.flying)){
            this.yv=-20 * this.gravity;
            this.onground=false;
        }
        else if (event.key == "ArrowDown" && this.cheat.flying){
            this.yv = 20 * this.gravity;
        }
        else if (event.keyCode==37){
            this.leftpressed=true;
        }
        else if (event.keyCode==39){
            this.rightpressed=true;
        }
    }
    run(){
        if (this.leftpressed || (this.joystick && this.joystick.left)){
            this.xv+=2;
        }
        if (this.rightpressed || (this.joystick && this.joystick.right)){
            this.xv-=2;
        }
        if (this.joystick && this.joystick.up && this.onground){
            this.yv = -20 * this.gravity;
            this.onground = false;
        }
        this.game.move(0,this.yv); // Y collisions
        colis=this.game.checkCollision();
        this.touchingice = false;
        if (colis["ice"] > 0){
            this.touchingice = true;

        }
        if (colis["tencoin"] > 0){
            this.score+=colis["tencoin"]*10;
            this.refreshscore();
        }
        if (colis["fiftycoin"] > 0){
            this.score+=colis["fiftycoin"]*50;
            this.refreshscore();
        }

        if (colis["launchpad"] > 0){
            this.yv = -25

        }

        if (colis["solid"] > 0 || (colis["killu"] > 0 && this.cheat.invincible)){
            if (this.cheat.phaser == 1){
                this.cheat.phaser = 2;


            }
            else if (this.cheat.phaser != 2){
                while (this.game.checkCollision()["solid"] > 0){
                    this.game.move(0,this.yv/Math.abs(this.yv) * -1);
                }
                if (this.yv*this.gravity > 0){
                    this.onground=true;
                }
                this.yv=0;
            }
        }
        else if (this.cheat.phaser == 2){
            this.cheat.phaser=0;
        }
        this.game.move(this.xv,0); // X collisions
        var colis=this.game.checkCollision();
        if (colis["tencoin"] > 0){
            this.score+=colis["tencoin"]*10;
            this.refreshscore();

        }
        if (colis["killu"] > 0 && !this.cheat.invincible){
            this.end();
        }
        if (colis["fiftycoin"] > 0){
            this.score+=colis["fiftycoin"]*50;
            this.refreshscore();
        }
        if (colis["solid"] > 0){
            if (this.cheat.phaser == 1){
                this.cheat.phaser = 2;
            }
            else if (this.cheat.phaser == 2){
                // Nothing!
            }
            else{
                while (this.game.checkCollision()["solid"] > 0){
                    this.game.move(this.xv/Math.abs(this.xv) * -1, 0);
                }
                this.xv=0;
            }
        }
        else if (this.cheat.phaser == 2){
            this.cheat.phaser=0;
        }
        if (this.touchingice){
          this.xv *= .95;

        }
        else{
          this.xv*=0.8;

}



///yv for physics y is up/down xv is left or right







        if (this.cheat.flying){
            this.yv *= 0.8
        }
        else{
            this.yv+=this.gravity;
        }
    }
    end(){
        window.alert(this.score);
        this.game.die = true;
    }
    refreshscore(){
        this.element.innerText=this.score.toString();
    }
}


class Game{
    constructor(mobile, xoffset=0,yoffset=0,brickwidth=50,brickheight=50){
        this.die = false;
        this.win = false;
        this.bricks=[];
        this.minigames=[];
        this.xoffset=0;
        this.yoffset=0;
        this.brickWidth=brickwidth;
        this.brickHeight=brickheight;
        this.player=new Player(mobile, 49,99,this);
        this.onkeyup = (event) => {
            this.player.onkeyup(event);
        };
        this.onkeydown = (event) => {
            this.player.onkeydown(event);
        };
        window.addEventListener('keydown', this.onkeydown);
        window.addEventListener("keyup", this.onkeyup);
        this.minigame = document.getElementById("minigame");
        this.minigameTick = 0;
        this.minigamePlaying = null;
        this.enemies = [];
        this.probPassers = [];
        this.runningEnemies = true;
        this.checkPoints = [];
        this.y = 0;
        this.x = 0;
        this.scale = 1;
    }
    _createBrick(x,y,width,height,renderclass,type,text,visibleText, probability){
        var x = new Brick(x+window.innerWidth/2+this.xoffset,y+window.innerHeight/2+this.yoffset,width,height, this.scale,renderclass,type,text,visibleText, probability);
        this.bricks.push(x);
        return x;
    }
    createBrick(x,y,horizLen, height, renderclass="regular",type="solid", probability){
        return this._createBrick(x*this.brickWidth,y*this.brickHeight,this.brickWidth * horizLen,this.brickHeight * height,renderclass,type, undefined, undefined, probability);
    }
    createHorizontal(x,y,width,renderclass="regular",type="solid"){
        this._createBrick(x*this.brickWidth,y*this.brickHeight,width*this.brickWidth,this.brickHeight,renderclass,type);
    }
    createVertical(x,y,height,renderclass="regular",type="solid"){
        this._createBrick(x*this.brickWidth,y*this.brickHeight,this.brickWidth,height*this.brickHeight,renderclass,type);
    }
    createSquare(x,y,width,height,renderclass="regular",type="solid"){
        this._createBrick(x*this.brickWidth,y*this.brickHeight,width*this.brickWidth,height*this.brickHeight,renderclass,type);
    }
    createSign(x,y,text,visibleText){
        this._createBrick(x * this.brickWidth, y * this.brickHeight, this.brickWidth, this.brickHeight, "sign", "notsolid", text,visibleText);
    }
    createMinigameBlock(x, y, minigameType){
        this._createBrick(x * this.brickWidth, y * this.brickWidth, this.brickWidth, this.brickHeight, "minigame", "minigame", undefined, undefined, minigameType);
    }
    createByLetter(x, y, width, height, letter){
        switch (letter) {
            case "r": // Regular, old - toy - story block.
                this.createBrick(x, y, width, height);
                break;
            case "c": // Coins
                this.createBrick(x, y, width, height, "tencoin", "tencoin")
                break;
            case "l": // Lava
                this.createBrick(x, y, width, height, "lava", "killu");
                break;
            case "C": // Big Coins
                this.createBrick(x, y, width, height, "fiftycoin", "fiftycoin");
                break;
            case "f":
                this.createBrick(x, y, width, height, "lava", "notsolid");
                break;/// fake lava
            case "F":
                this.createBrick(x, y, width, height, "regular", "notsolid");
                break;/// fake block
            case "i":
                this.createBrick(x, y, width, height, "invisible", "solid");
                break;/// invisible regular
            case "I":
                this.createBrick(x, y, width, height, "invisible", "killu");
                break;/// invisible lava
            case "G":
                this.createBrick(x, y, width, height, "lava", "solid");
                break;/// lava
            case "e":
                this.enemies.push([this.createBrick(x, y, width, height, "lava", "killu"), 5, 0]);
                break;/// moving lava
            case "ǝ":
                this.enemies.push([this.createBrick(x, y, width, height, "lava", "killu"), -5, 0]);
                break;//moving lava
            case "z":
                this.createBrick(x, y, width, height, "invisible", "elevator");
                break;///lauch lava
            case "Z":
                this.createBrick(x, y, width, height, "invisible", "bigElevator");
                break;/// launch enemys
            case "v":
                this.createBrick(x, y, width, height, "invisible", "notsolid");
                break;/// idk
            case "p":
                this.createBrick(x, y, width, height, "regular", "solid", 0.1);
                break;///same with this
            case "P":
                this.createBrick(x, y, width, height, "regular", "solid", 0.5);
                break;/// idk what this is yet
            case "d":
                this.createBrick(x, y, width, height, "invisible", "enemyFlipperRight");
                break;///moving enemy stuff
            case "D":
                this.createBrick(x, y, width, height, "invisible", "enemyFlipperLeft");
                break;///moving enemy stuff
            case "k":
                this.checkPoints.push([x, y]);
                break;/// idk
            case "n":
                this.createBrick(x, y, width, height, "end", "end");
                break;/// n for end
                case "y":
                    this.createBrick(x, y, width, height, "ice", "ice");
                    break;/// y beacause nothing else i used worked
                case "u":
                        this.createBrick(x, y, width, height, "launchpad", "launchpad");
                        break;// u is for launchpad
        }
    }
    createByTileset(x,y,tileset, signs){
        var ix=x;
        var iy=y;
        var curHoriz = 0;
        var curHorizType = "";
        var signNum = 0;
        tileset.split("").forEach((item, i) => { // Types that cannot be chained: C, c, e, ǝ.
            /*    if (curVerts[ix][0] == item){
                    curVerts[ix][1] ++;
                }
                else if (curVerts[ix][1] != 0){
                    this.createByLetter(iy - curVerts[ix][1], ix, 1, curVerts[ix][1]);
                }
            }
            else*/{/*
                if (tileset[i - 1] != item && tileset[i + 1] != item && curHoriz == 0){
                    curVerts[ix] = [item,1];
                }
                else*/{
                    if (item == "s"){
                        this.createSign(ix, iy, signs[signNum]);
                        signNum ++;
                    }
                    if (item == tileset[i - 1] && ["e", "c", "C"].indexOf(tileset[i - 1]) == -1){
                        curHoriz ++;
                    }
                    else{
                        if (curHoriz != 0){
                            this.createByLetter(ix - curHoriz, iy, curHoriz, 1, tileset[i - 1]);
                            curHoriz = 0;
                        }
                        this.createByLetter(ix, iy, 1, 1, item); // This has to happen anyways, so may as well let it happen now
                    }
                }
            }
            ix++;
            if (item == "\n"){
                ix = x;
                iy ++;
            }
        });
    }
    createHollowSquare(x,y,width,height,renderclass="regular",type="solid"){
        width-=1;
        height-=1;
        this.createHorizontal(x,y,width,renderclass,type);
        this.createVertical(x,y-height,height,renderclass,type);
        this.createHorizontal(x+1,y-height,width,renderclass,type);
        this.createVertical(x+width,y-height+1,height,renderclass,type)
    }
    move(xm,ym){
        this.bricks.forEach((item, i) => {
            item.move(xm,ym*-1);
        });
        this.x += xm;
        this.y -= ym;
    }
    apply(){
        this.bricks.forEach((item, i) => {
            item.apply();
        });
    }
    checkCollision(object = this.player, holes = false, supercilious = false){ // Collisions are a pixel smaller than they should be, if "holes" = true. Supercilious makes it 2 pixels to account for tidal drag.
        var dictionary={
            "solid":0,
            "notsolid":0,
            "killu":0,
            "tencoin":0,
            "fiftycoin":0,
            "minigame":0,
            "elevator":0,
            "bigElevator":0,
            "end":0,
            "all":0,
            "ice":0,
            "launchpad":0,
        }; // Supported solidities: Solid, Notsolid, Killu
        var passers = 0;
        this.bricks.forEach((item, i) => {
            if (item.probprob != 1){
                passers ++;
            }
            if (((item.x2 >= object.x1 &&
                item.x1 <= object.x2 &&
                item.y2 >= object.y1 &&
                item.y1 <= object.y2 && !holes && !supercilious)
                || (item.x2 > object.x1 &&
                    item.x1 < object.x2 &&
                    item.y2 > object.y1 &&
                    item.y1 < object.y2 && holes && !supercilious)
                    || (item.x2 - 1 > object.x1 &&
                        item.x1 + 1 < object.x2 &&
                        item.y2 > object.y1 &&
                        item.y1 < object.y2 && supercilious)))
            {
                if (item.probprob > Math.random()){
                    dictionary[item.type]++;
                    if (item.type=="tencoin" || item.type=="fiftycoin"){
                        item.element.parentNode.removeChild(item.element);
                        this.bricks.splice(i,1);
                    }
                    if (item.type=="minigame"){
                        dictionary["solid"]++;
                        this.playMinigame(item.element.getAttribute("data-minigame"));
                    }
                    if (!(item.type=="elevator" || (item.type == "bigElevator") || item.type == "enemyFlipper")){
                        dictionary["all"]++;
                    }
                    if (item.type == "end"){
                        this.win = true;
                    }
                    if (item.type == "ice"){
                        dictionary["solid"] ++;
                    }
                }
                else if (!this.probPassers.includes(object)){
                    this.probPassers.push(object);
                }
            }
        });
        if (passers == 0 && this.probPassers.includes(object)){
            this.probPassers = this.probPassers.filter(function(value, index, arr){
                return value == object;
            });
        }
        return dictionary;
    }

    run(){
        if (this.die || this.win){
            if (this.win){
                document.getElementById("gamewin").style.display="block";
                document.getElementById("gamewin").innerText = "You beat the level! Your score: " + this.player.score;
                window.levelsBeaten ++;
                if (window.levelsBeaten == window.phases[window.phase - 1].length){
                    window.phase ++;
                    loadPhase(window.phase);
                }
                var variab = document.getElementById(document.querySelector("#levelselect > select").value);
                variab.parentNode.removeChild(variab);
            }
            if (this.die){
                document.getElementById("gameover").style.display="block";
            }
            window.removeEventListener('keydown', this.onkeydown);
            window.removeEventListener("keyup", this.onkeyup);
            this.bricks.forEach((item, i) => {
                item.delete();
                item = null;
            });
            this.enemies.forEach((item, i) => {
                item = null;
            });
            this.player.delete();
            this.bricks = null;
            this.enemies = null;
            this.player = null;
            setTimeout(() => {
                document.getElementById("gameover").style.display="none";
                document.getElementById("gamewin").style.display="none";
                document.getElementById("menu").style.display="";
            }, 2000);
            return true;
        }
        if (this.minigamePlaying){
            var city = this.minigames[this.minigamePlaying](this.minigame, this.minigameTick); // Should return 0 or any other falsey number if no effect, 1 if the player wins, 2 if the player loses.
            if (city == 1){
                 this.minigame.style.display = "none";
                 this.minigamePlaying = false;
            }
            else if (city == 2){
                minigameActiveBlock = this.minigameActiveBlock.element;
                this.minigameActiveBlock.parentNode.removeChild(this.minigameActiveBlock);
                this.bricks = this.bricks.filter(item => item !== this.minigameActiveBlock);
            }
            this.minigameTick ++;
        }
        else{
            this.player.run();
            this.apply();
        }
        if (this.runningEnemies){
            this.enemies.forEach((item, i) => {
                item[2] ++;
                item[0].move(0, item[2]);
                var df = this.checkCollision(item[0], true);
                if (df["all"] > 1){
                    while (this.checkCollision(item[0], true, true)["all"] > 1){item[0].move(0, item[2] / Math.abs(item[2]) * -1)};
                    item[2] = 0;
                }
                for (var i = 0; i < Math.abs(item[1]); i++){
                    var loofa = false;
                    item[0].move(0, 1);
                    if (this.checkCollision(item[0], true, true)["all"] > 1){
                        item[0].move(0, -1);
                    }
                    else{
                        loofa = true;
                    }
                    item[0].move(item[1] / Math.abs(item[1]), 0);
                    var df = this.checkCollision(item[0], true, true);
                    if (df["all"] > 1){
                        item[0].move(item[1] / Math.abs(item[1]) * -1, 0);
                        if (loofa == false){
                            item[1] *= -1;
                        }
                    }
                    else if (loofa == true){
                        item[0].move(0, -1);
                    }
                    if (df["elevator"] > 0){ // Elevator bricks make them hop
                        item[2] = -15;
                    }
                    if (df["bigElevator"] > 0){
                        item[2] = -40;
                    }
                    if (df["enemyFlipper"] > 0){
                        item[1] *= -1;
                    }
                }
            });
        }
    }

    registerMinigame(name, play){ // Register minigame functions. All should take the element to draw on (dynamic!), play should also take the tick value.
        this.minigames[name] = play;
    }

    playMinigame(name){
        this.minigame.style.display = "block";
        this.minigamePlaying = name;
        this.minigameTick = 0;
    }
    toggleEnemies(){
        this.runningEnemies = !this.runningEnemies;
    }
}

var g=null;
document.getElementById("playbutton").addEventListener("click",function(){
    g=new Game(document.querySelector("#mobileOrNot > input").checked);

    // Drawing here!
    switch(document.querySelector("#levelselect > select").value){
        case "1":
            g.createByTileset(-5, 6, the_plains, ["Beware! This is a junction! The original creator designed what you will find if you go down, another designed what you will find if you keep on going this way. Neither play is revocable. Choose your poison!"]);
            break;
        case "2":
            g.createByTileset(-3, -8, lvl1);
            break;
        case "3":
            g.createByTileset(-4, -12, DESTRUCTION);
            break;
        case "4":
            g.createByTileset(-3, -6, lvl2, ["You have a superpower. An extra jump! Slide off a platform without jumping and you can jump in mid-air to fly."]);
            break;
        case "5":
            g.createByTileset(-5, -5, actual_maze, ["This one is a real maze. There is only one way out. Best of luck!", "Ah yes. Looks like you've found the less painful way out! I recommend you take a temporary detour, you'll get plenty coins that way.", "You didn't find the easy route at all. Haha!", "This is the end of the level."]);
            break;
        case "6":
            g.createByTileset(-2, 0, tinymaze);
            break;
        case "7":
            g.createByTileset(-2, 0, training, ["Look - lava! Sail over it with the 'up' and 'right' keys to avoid dying.", "As you can see, these are coins. Run into them to claim them, you'll notice you gain a score counter!<br /> The moving lava below you will hurt you just as bad as normal lava, so you should make sure to dodge it when you try to get the coin.", "this is ice i fixed it!!!","this is a jump block use it to hop up hit it at the right angle for it to fling you"])
            g.createSign(1, 1, "Welcome to Platformer! This is a short, simple training level designed to get you on your feet.<br />What you have hovered is a sign. You should always hover them, they have useful information.<br />To start out, try moving the player with the left and right arrow keys", "Mouse Over Me", )
            break;
        case "8":
            g.createByTileset(-2, -5, fortress);
            break;
        case "9":
            g.createByTileset(0, 0, DEATH);
            break;

    }
    document.getElementById("menu").style.display="none";
    Array.from(document.getElementsByClassName("tencoin")).forEach((item, i) => {
        item.innerHTML="<p class='coin_text'>10</p>";
    });
    Array.from(document.getElementsByClassName("fiftycoin")).forEach((item, i) => {
        item.innerHTML="<p class='coin_text big'>50</p>";
    });

    c=setInterval(function(){
        if (g.run()){
            clearInterval(c);
        }
    }, 20);
});

loadPhase(window.phase);
